import { tagsTemplate } from './data.js';

export function parseData(data) {
    console.log('Parsing data:', data.substring(0, 100) + '...');
    const lines = data.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    console.log('Found lines:', lines.length);
    const items = [];
    let currentItem = null;

    lines.forEach(line => {
        // Sprawdź czy to jest akcesoria
        const isAccessory = line.toLowerCase().includes('okulary') || 
                          line.toLowerCase().includes('plecak') ||
                          line.toLowerCase().includes('czapka') ||
                          line.toLowerCase().includes('klapki') ||
                          line.toLowerCase().includes('bucket');
        
        // Sprawdź czy to jest linia z wymiarami
        const hasMeasurements = line.match(/^[pdsun]\s*\d+/i);

        // Sprawdź czy linia zawiera nazwy ubrań
        const hasClothingWord = /\b(bluza|spodnie|koszulka|kurtka|jeansy|szorty|jersey|longsleeve|spodenki|catana|bomberka|koszula)\b/i.test(line);
        
        // Sprawdź czy linia zawiera rozmiar
        const hasSize = line.toLowerCase().includes('size') || /\b(xs|s|m|l|xl|xxl|xxxl|\d+xl|\d+\/?\d*)\b/i.test(line);

        // Sprawdź czy to nowy przedmiot
        const isNewItem = !hasMeasurements && (isAccessory || hasClothingWord || hasSize);
        
        console.log('Processing line:', {
            line,
            isAccessory,
            hasMeasurements,
            hasClothingWord,
            hasSize,
            isNewItem
        });

        if (line && isNewItem) {
            if (currentItem) {
                items.push(currentItem);
                console.log('Added item:', currentItem);
            }
            currentItem = { rawTitle: line, details: [], isAccessory };
            console.log('Created new item:', currentItem);
        } else if (currentItem && !line.includes(tagsTemplate)) {
            currentItem.details.push(line);
        }
    });

    if (currentItem) {
        items.push(currentItem);
        console.log('Added final item:', currentItem);
    }

    console.log('Total items found:', items.length);
    return items;
}

export function formatTitle(item) {
    const rawTitle = item.rawTitle;
    // Podziel tytuł na słowa
    const words = rawTitle.split(' ');
    
    // Przetwórz pierwsze trzy słowa aby zaczynały się wielką literą
    const processedWords = words.map((word, index) => {
        if (index < 3) {
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        }
        return word;
    });
    
    return processedWords.join(' ');
}

export function formatItem(item) {
    const rawTitle = item.rawTitle;
    const details = item.details;
    const isAccessory = item.isAccessory;

    // Extract size from title
    let size = '';
    
    // Sprawdź najpierw "size" z numerem/literą
    const sizeWithWordMatch = rawTitle.match(/size\s+([^\s]+)/i);
    if (sizeWithWordMatch) {
        size = sizeWithWordMatch[1].toUpperCase();
    } else {
        // Sprawdź samodzielne oznaczenia rozmiaru
        const sizeRegex = /\b(XS|S|M|L|XL|XXL|XXXL|[2-5]?XL|(?:2[0-9]|3[0-9]|4[0-9]|50))\b/i;
        const standaloneSizeMatch = rawTitle.match(sizeRegex);
        if (standaloneSizeMatch) {
            size = standaloneSizeMatch[1].toUpperCase();
        }
    }

    // Extract condition
    const condition = rawTitle.includes('bez wad') ? 'Stan idealny / Bez wad' : 'Stan dobry';

    // Process measurements
    const measurements = [];
    
    if (!isAccessory) {
        // For regular items, process all measurements
        details.forEach(detail => {
            // Rozdziel tekst na słowa, ignorując wielokrotne spacje
            const parts = detail.trim().split(/\s+/);
            
            // Przetwarzaj parami (typ pomiaru + wartość)
            for (let i = 0; i < parts.length - 1; i++) {
                const type = parts[i].toLowerCase();
                const value = parts[i + 1];
                
                // Sprawdź czy wartość jest liczbą
                if (!isNaN(value)) {
                    if (type === 'p' || type === 'pas') {
                        measurements.push(`Pas ${value} cm`);
                        i++; // Przeskocz następny element, bo już go użyliśmy
                    } else if (type === 'd' || type === 'dl') {
                        measurements.push(`Długość ${value} cm`);
                        i++;
                    } else if (type === 's') {
                        measurements.push(`Szerokość ${value} cm`);
                        i++;
                    } else if (type === 'u') {
                        measurements.push(`Udo ${value} cm`);
                        i++;
                    } else if (type === 'n') {
                        measurements.push(`Nogawka ${value} cm`);
                        i++;
                    }
                }
            }
        });
    }

    // Clean up the title (remove size and condition info)
    const cleanTitle = rawTitle
        .replace(/size\s+[^\s]+/i, '')
        .replace(/bez wad/i, '')
        .replace(/z wadami/i, '')
        .trim();

    // Format the output
    const titleSection = "🌟 " + cleanTitle + " 🌟";
    const stateSection = "📌 **Stan:** " + condition;
    const sizeSection = !isAccessory && size ? 
        "📏 **Rozmiar:** " + size : 
        "📏 **Rozmiar:** uniwersalny";
    
    const measurementsSection = !isAccessory && measurements.length > 0 ? 
        "\n📐 **Wymiary:**\n" + measurements.join('\n') : 
        '';

    let output = "💎 Jak chcesz wiedzieć wcześniej o itemach zapraszam na instagram kamochi.store 💎\n\n";
    output += titleSection + "\n\n";
    output += stateSection + "\n";
    output += sizeSection;
    if (measurementsSection) output += measurementsSection;
    output += "\n\n" + tagsTemplate;
    return output;
}
