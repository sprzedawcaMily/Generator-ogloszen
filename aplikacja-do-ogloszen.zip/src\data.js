const data = `
Bluzy, Kurtki, Jeansy i Akcesoria
roca wear jersey długi rękaw, granatowy, size L bez wad
d 77 s 60

ecko unltd jortsy size 38 granatowe bez wad
p 48 d 60 u 40 n 32

phat farm jeansy size 34/34 nogawki poszczerbione
p 45 d 107 u 38 n 24

rydel house jeansy z fajnym ziutkiem na kiermanie size 36 bez wad
p 46 d 102 u 38 n 25

fishbone jortsy size M dla dziewczynki bez wad
p 40 d 53 u 31 n 23

unc jeansy z fajnymi haftami size 30 bez wad
p 41 d 110 u 35 n 23

affliction koszula długi rękaw zielona size XL bez wad
d 81 s 57

DC bluza dwustronna size L bez wad
d 70 s 60

Mass Denim bluza moro size S cracking
d 67 s 54

akademiks bluza granatowa szeroka size XL bez wad
d 78 s 68

Konflic long sleeve bialy full print bez wad
d 80 s 62

raw blue zonobijka z rekawicami ze skory czarny size M dzieciece bez wad
d 64 s 43

KKO bluza zip niebieska size M fullprint bez wad
d 69 s 57

Karl Kani jeansy czarne hafty na tyle size 32/32 patka wycieta
p 39 d 111 u 34 n

raw blue jeansy szare size 40 bez wad print skrzydel na tyle
p 50 d 108 u 37 n 25

crown holder jeansy czarne z dywanem w srodku size 38 bez wad
p 50 d 109 u 38 n 24

g unit bezowe spodnie z printem na zadku size 34 bez wad
p 46 d 110 u 35 n 23

extreme couture rozowy t-shirt size 2XL bez wad
d 81 s 70

tapout mps czarny long sleeve bez wad size M
d 70 s 54

affliction czarny t-shirt size L BEZ WAD
d 79 s 56

Mass denim jortsy size XL bez wad
p 45 d 64 u 42 n 34

your local dealer full print z haftami size 34 bez wad
p 42 d 103 u 34 n 22

G unit jeansy pozlacane bez wad size 38
p 50 d 117 u 40 n 25

levis silver tap size 34 poszarpane nogawki
p 46 d 108 u 38 n 23

coogi bluza 5XL w kratki bez wad kolorowa
d 83 s 85

mma elite t-shirt szary size M bez wad
d 69 s 52

DogTown szary long sleeve dla dziewczyny bez wad size L
d 58 s 48

blind jeansy size 34 nogawka poszczerniona plamka
p 42 d 109 u 35 n 24

K1X dresy welurowe z lampasem size 3XL bez wad
p 54 d 110 u 43 n 13

dada supreme XL bezowy zestaw bez wad
bluza d 77 s 62
spodnie p 42 d 107 u 35 n 24

hood boyz czarno bialy set size XL bez wad
bluza d 78 s 63
spodnie p 45 d 113 u 41 n 20

coogi jeansy size 40 poszarpane
p 48 d 112 u 40 n 27

ccm jersey dlugi rekaw czerwony bez wad size S
d 69 s 60

wokal jeansy fajne hafty bez wad ogromne size 44
p 54 d 121 u 45 n 28

spodenki oakley bordowe bez wad size m
p 43 d 55 u 37 n 30

mammoth spodnie szare rozsuwane nogawki szare size M bez wad
p 40 d 101 u 32 n 26

fubu platinum fat albert koszula ogromna 3XL bez wad
d 92 s 75

stoprocent bluza zip szara M bez wad
d 73 s 61

and1 spodenki koszykarskie czerwone 3XL bez wad
p 45 d 62 u 46 n 42

fubuplatinum jeansy koszykowe szare z haftami bez wad
p 44 d 114 u 39 n 23

B3 bluza brazowa size 2XL BEZ WAD
d 75 s 68

ecko unltd koszulka czerwona L bez wad
d 61 s 51

b3 jeansy size 34 bez wad fajne takie
p 42 d 110 u 36 n 24

ecko unltd z haftami biala full print L bez wad
d 65 s 50

roca wear bluza biala fajna size XL bez wad ladna
d 67 s 63

dada supreme czerwona koszulka size XL bez wad
d 70 s 57

fubu bomberka biala bez wad size M
d 63 s 62

oakley bluza czarna z printem zip size L
d 72 s 57

plecak oakleya czerwony

czapka z daszkiem southpole

czapka z daszkiem dc

czapka z daszkiem oakley

b3 kurtka czarna bez wad fajna size L
d 63 s 66

ecko unlt koszulka czarna bez wad mma
d 68 s 53

iriedaily bluza szara size L bez wad
d 70 s 58

ed hardy jeansy z szelkami fajne kiermany bez wad size 31
p 43 d 96 u 31 n 19

vocal jortsy size 38 bez wad ogromne
p 50 d 70 u 43 n 35

ecko unltd fulll print biala XL bez wad
d 73 s 60

Townz bluza e-sportowa czarna bez wad zip
d 61 s 60

superr radical x brooklyn project koszulka szara male dziurki size XL
d 76 s 58

mass 98 koszula fajne metki size XL w krate bez wad
d 78 s 68

dc spodnie size M czarne biale nitki bez wad
p 41 d 101 u 40 n 23

plecak mammoth czerwony turystyczny z stelazem

southpole jeansy czarne z epickimi kieszonkami bez wad size 40
p 50 d 116 u 39 n 26

tapout czarny print 3XL koszulka bez wad
d 75 s 65

and 1 spodenki sportowe niebieskie size 3 XL bez wad
p 48 d 65 u 47 n 43

mass denim jeansy niebieskie model juicy pussy bez wad size L
p 44 d 109 u 38 n 24

ecko unltd bluza biala full print size M bez wad
d 67 s 68

smiths wlatcy moch czerwona M bez wad
d 69 s 49

ecko unltd jortsy baggy fit size 36 bez wad
p 48 d 66 u 38 n 32

malita jortsy size XL bez wad
p 46 d 54 u 35 n 27

karl kani jersey ogromny bialy size XL bez wad
d 81 s 72

dc x monster koszulka zielona size XL male dziurki
d 73 s 50

roca wear bluza zip szara size M bez wad
d 71 s 67

Tapout z printem bluza na ramiaczka size L bez wad
d 73 s 60

south pole koszula dla saggera granatowa bez wad size M nowa z metka
d 76 s 58

clinic manufacture blekitna koszulka ogromna bez wad size XL
d 82 s 64

ecko unltd koszulka biala size XL dzieciece bez wad
d 70 s 50

LGB spodnie z cienkiego materialu szare size 3 bez wad
p 40 d 118

mass denim limited M bez wad
p 42 d 109 u 40 n 23

really point bluza zip czarna full print size L bez wad
d 72 s 62

rydel house catana size XL bez wad
d 81 s 63

tapout czarna koszulka print L bez wad
d 72 s 56

MSBHV kurtka z welny size L bez wad szara
d 70 s 65

southpole moro jasno szare size 36 bez wad
p 45 d 112 u 39 n 26

clinic model 4 size M dziurka
p 45 d 109 u 41 n 24

bottle bluza granatowa size L bez wad
d 70 s 60

fubu jortsy size 30 fajne bez wad
p 41 d 63 u 36 n 30

johnny blaze x marvel jeansy nowe z metka size 38
p 50 d 115 u 38 n 25

5ive jungle zielona koszulka epicka size 2XL bez wad
d 85 s 64

elpolako x jamal koszulka niebieska XL bez wad
d 80 s 62

karl kani bluza czarna zip ful print size L bez wad
d 67 s 68

mass denim koszulka biala cracking XL
d 71 s 56

tapout koszulka szara z printem fajnym 2 XL bez wad
d 76 s 61

G unit koszulka biala z zlotym nadrukiem size L bez wad
d 70 s 53

fox long sleve przewiewny niebieski L dziurki
d 74 s 59

senate bluza granatowa z kapturem size XL bez wad
d 75 s 65

afliction t-shirt szary full print 2 XL bez wad
d 80 s 60

pelle pelle szara bluza zip size M nie dziala suwak
d 75 s 59

sancezz size M czarne spodenki bez wad
p 44 d 56 u 36 n 32

fox long sleve czerwony przewiewny size L bez wad
d 78 s 58

dox long sleve seledynowo czarny size L przetarcia
d 73 s 57

fox long sleve kolorowy size L bez wad
d 77 s 63

fishbone jersey koszykarski granatowy size XL bez wad
d 70 s 65

fubu sports koszulka bezowa size XL bez wad
d 77 s 63

ed hardy czarna kurtka size L BEZ WAD
d 68 s 57

supreme koszulka czarna size M cracking
d 72 s 56

wu tanG koszulka szara dziurka mala size M
d 65 s 54

Hemp gru bluza czarna size M bez wad
d 82 s 57

affliction spodenki biale size 30 bez wad
p 42 d 52 u 35 n 30

moro sport spadochrony bezowe size 2XL bez wad
p 50 d 114 u 48 n 24

moro sport bluza bezowa L bez wad
d 71 s 66

karl kani bluza z dupeczka czarna zip size XL bez wad
d 74 s 68

Raw Blue czarna bluza zip size XL bez wad
d 71 s 65

and one dresy sportowe xl
p 38 d 98 u 31 n 24

clinic ddekady baggy xl
d 66 s 55

supreme koszulka m
d 71 s 47

jigga wear M polo
d 71 s 52

mma elite spodenki bokserski 10/12 boys
p 37 d 51 u 30 n 26

eminem d 12 jersay m plamka
d 67 s 54

dresy jigga wear lekko poszarpane poplamione size m
p 42 d 96 u 35 n 21

mammut spodnie trekingowe m
p 52 d 104 u 27 n 12

fubu sport XXL biala bluza sport
d 75 s 63

bluza y3 szara m
d 67 s 55

bluza ecko unltd z lat 90 XL
d 70 s 65

toy machine XL tis
d 74 s 60

dada supreme spodenki krotkie zielone 32
p 41 d 62 u 36 n 29

tapout czarny w tribale l
d 68 s 53

spodnie suhu baggy swieciace
p 40 d 102 u 35 n 37

levis silver tab baggy 36
p 43 d 98 u 36 n 20

bluza fishbone biala Xl
d 68 s 66

spodenki oakley na rower
p 43 d 42 u 35 n 30

koman jeans niebieskie spodenki fajne z printem 32
p 40 d 62 u 34 n 30

spodenki g unit dresowe wygodne L
p 40 d 60 u 40 n 33

xtreme couture nowe z metka L
d 78 s 53

koszula affliction L
d 72 s 52

southpole XL full print
d 85 s 68

dc gruba XL czerwona
d 70 s 58

mma elite longsleve XXL opium
d 77 s 64

fishbone koszula XL
d 78 s 57

liquidn blue XXL czaszki
d 71 s 65

fox jersey M
d 65 s 49

bucket edhardy

rydelhouse spodenki
p 41 d 68 u 36 n 30

bluza rydelhouse L
d 78 s 67

bluza hoodboyz
d 76 s 68

bluza focusspace plamka
d 81 s 62

koszulka dc monster
d 71 s 52

spodenki us40
p 38 d 58 u 33 n 26

wuntangclan bluza xl boxy stopy
d 72 s 68

plecak dc

spodnie ecko baggy 36
d 118 p 50 u 37 n 26

koszyulka rydelhouse
d 75 s 52

bluza joker 3XL
d 72 s 71

spodnie ecko 36
p 50 d 111 u 37 n 35

koszulka christian
d 79 s 55

bluza phatfarm L boxy
d 70 s 65

spodnie ruuf
p 47 115 u 39 n 26

bluza topout szara L
d 70 s 57

bluza lordstyles XL
d 75 s 69

DADA L spodenki
p 43 d 57 u 36 n 34

hoodboyz secik full print 2XL szary bez wad
bluza d 83 s 67
spodnie p 45 d 114 u 39 n 23

ufo pants czarne szelesty size L bez wad
p 50 d 114 u 45 n 28

duffs XL bluza szara bez wad
d 76 s 64

fishbone jeansy poszarpane nogawki z haftem na kieszeni XL
p 47 d 116 u 39 n 27

liquid blue acdc M 80s bez wad
d 69 s 56

ecko unltd bluza czarna size S bez wad
d 63 s 59

liquid blue acdc szara bluza size L bez wad zip
d 77 s 59

phat farm lonmg sleeve granatowa size L bez wad
d 72 s 63

joker brand bluza czarna ogromna 4XL bez wad
d 79 s 80

jeansy raw blue uzbrojone w timby bez guziczka size 36
pas 45 d 105 u 35 n 25

tapout ufc koszulka z zielonym printem size M bez wad
d 74 s 52

fox x monster bluza szara size L bez wad
d 71 s 60

clinic wiatrówka czerwona XL bez wad
d 75 s 70

southpole bluza granatowa size M bez wad
d 68 s 59

akademiks full print bluza szara zip size L bez wad
d 68 s 65

mecca bluza biala zip fajna
d 71 s 67

time is mone bluza zip czarna size m bez wad
d 65 s 60

sweter cooogi szary welniany bez wad size M
d 64 s 57

sean john jeansy ogromne size 42 bez wad
p 55 d 108 u 44 n 27

pelle pelle jeansy size 34 bez wad
p 45 d 116 u 40 n 25

aem-kei jeansy fajne bez wad
p 46 d 115 u 38 d 25

no fear bluza czarna size L bez wad
d 72 s 60

ecko unltd koszulka szara ogromna XL bez wad
d 83 s 68

zero six jersey POLSKA size L bez wad
d 78 s 60

dada supreme bliza zip kolorowa size M bez wad full prin
d 68 s 62

oakley dresy sportowe blekitne size L zaciagnieca na kolanie
p 44 d 98 u 33 n 23

fishbone bluza czarna zip size 2XL bez wad
d 57 s 49

koszula dragon ball niebieska i epicka size L
d 67 s 60

clh secik full print w ziomali size XL bez wad
catana d 73 s 62
spodnie p 48 d 118 u 39 n 25

vocal jeansy size 34 bez wad
p 42 d 117 u 37.5 n 24

sean john bluza zielona size XL
d 78 s 65

cropp bomberka jeansowa z haftem na plecach size XL bez wad
d 80 s 62

Karl kani jeansy size 33 bez wad
p 44 d 108 u 36 n 24

maci gear moro spodenki 2018 vibe size 32 bez wad
p 42 d 63 u 37 n 31

southpole size 42 jeansy duze nogawki poszarpana
p 55 d 103 u 37 n 26

kosmolupo jeansy size 36 haft na dupie bez wad
p 51 d 109 u 35 n 22

joker bluza czarna 4XL boxy
d 80 s 78

moro bluza zip z kolorowymi nitkami size XL bez wad
d 71 s 59

rydel house rycerska kurtka size L bez wad szara
d 78 s 67

ELPOLAKO koszulka z ziomalem zielonym michalem size M bez wad
d 67 s 58

Taput MPS czarny t-shirt z fajnym printem XL bez wad
d 78 s 60

fubu jeansy szerokie size 34 bez wad
p 44 d 108 u 40 n 23

ecko unltd koszulka szeroka fajna szara size XL bez wad
d 75 s 68

Koszula soutpole niebieska size L bez wad
d 80 s 64

G uinit koszula dla saggera blekitna size XL bez wad
d 76 s 63

TAPOUT czarny z Bialym printem size L bez wad
d 70 s 55

fishbone czerwona koszula XL BEZ WAD
d 78 s 68

5ive junge niebieska koszula z odblyskiem size 2XL bez wad
d 80 s 67

dc x monster kapielowski bez wad size 38
p 49 d 59 u 38 n 34

karl kani jeansy niebieskie size 34 bez wad
p 45 d 113 u 35 n 24

outkast jeansy czarne size 36 bez wad
p 42 d 110 u 39 n 26

phatfarm jeansy niebieskie size 40 bez wad
p 52 d 97 u 35 n 24

artful dodger jeansy z fajnym haftem size 34 bez wad
p 47 d 108 u 35 n 24

mecca dnm jeansy size 34 bez wad
p 44 d 109 u 39 n 27

sean john jeansy cekinowe kieszenie size 42 bez wad
p 53 d 115 u 40 n 24

twinners jeansy size XXL bez wad
p 41 d 109 u 35 n 25

pell pelle jeansy jasne size 40 ogromne nogawa poszarpana
p 53 d 115 u 41 n 26

sohk bluza szara z ziomeczkiem size XL
d 74 s 65

sir beni miles bezowe szelesty size L bez wad
p 45 d 108 u 37 n 25

tapout bluza nieieska size L skjulkowana
d 68 s 60

moro bezowa bomberka size M bez wad
d 70 s 66

sanhorn blue jeansy size 38 bez wad
p 48 d 111 u 38 n 20

smiths x wlatcy moch long sleeve czarny M bez wad
d 66 s 51

KOMAN jeansy size 30 bez wad
p 40 d 105 u 35 n 24

tapout koszulka czarna XL typu afliction bez wad
d 76 s 57

work industries szara koszulka size L
d 74 s 55

SOUTHPOLE czarna koszulka M bez wad z fajnym printem
d 82 s 55

mentor spodenki moro size M bez wad
p 44 d 66 u 37 n 31

sean john jeansy czarne size 36 bez wad
p 49 d 113 u 38 n 25

okulary oakley niezly meksyk

brand new fox x monster klapki
`;

const tagsTemplate = `hiphop rap skate vintage OG 90s 00s y2k baggy szerokie swag drip usa fubu southpole fishbone bigboy polar emo rave drain tribal dickies carhartt cargo carpenter boxy kani mass clinic jigga metoda elpolako stoprocent clinicmanufacture clinicmfe cnc mfe polskamarka og boxlogo centerlogo alien ufo ftp pnb tribal graffiti skate sk8 deskorolka rap hiphop freestyle mc breakdance bboy drip drill y2k 90s OOS archive rare grail error jigga malita bottle btl b3 befree etylina metodasport morosport mentor mass lenar rydelhouse blackzone jnco oldschool boxyfit fubu sohk southpole karlkani pellepelle johnnyblaze dadasupreme sancezz rawblue drain gang cyber edgy alternative aesthetic
#hiphop #rap #skate #vintage #OG #90s #00s #y2k #baggy #szerokie #swag #drip #usa #fubu #southpole #fishbone #bigboy #polar #emo #rave #drain #tribal #dickies #carhartt #cargo #carpenter #boxy #kani #mass #clinic #jigga #metoda #elpolako #stoprocent #clinicmanufacture #clinicmfe #cnc #mfe #polskamarka #og #boxlogo #centerlogo #alien #ufo #ftp #pnb #tribal #graffiti #skate #sk8 #deskorolka #rap #hiphop #freestyle #mc #breakdance #bboy #drip #drill #y2k #90s #OOS #archive #rare #grail #error #jigga #malita #bottle #btl #b3 #befree #etylina #metodasport #morosport #mentor #mass #lenar #rydelhouse #blackzone #jnco #oldschool #boxyfit #fubu #sohk #southpole #karlkani #pellepelle #johnnyblaze #dadasupreme #sancezz #rawblue #drain #gang #cyber #edgy #alternative`;

const measurementMap = {
    'p': 'Pas', 'pas': 'Pas',
    'd': 'Długość', 'dl': 'Długość', 'dł': 'Długość', 'dlugi': 'Długość',
    's': 'Szerokość', 'szer': 'Szerokość',
    'u': 'Udo', 'udo': 'Udo',
    'n': 'Nogawka', 'nog': 'Nogawka',
};

const brandMap = {
    'ecko unltd': 'Ecko Unlimited',
    'phat farm': 'Phat Farm',
    'rydel house': 'Rydel House',
    'dc': 'DC',
    // ... reszta marek
};

export { data, tagsTemplate, measurementMap, brandMap };
