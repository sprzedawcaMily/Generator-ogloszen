export const carBrands = [
  'Toyota',
  'Honda',
  'Ford',
  'BMW',
  'Mercedes',
  'Audi',
  'Volkswagen',
  'Hyundai',
  'Kia',
  'Mazda',
];
