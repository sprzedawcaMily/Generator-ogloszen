declare module './notionFetcher' {
    export function fetchNotionData(): Promise<string[]>;
}
